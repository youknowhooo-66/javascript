let input1 = document.getElementById("inptnb1")
let input2 = document.getElementById("inptnb2")
let input3 = document.getElementById("inptnb3")
let x

function Soma(){
    x = Number(input1.value) + Number(input2.value) + Number(input3.value)
    alert(x)
}